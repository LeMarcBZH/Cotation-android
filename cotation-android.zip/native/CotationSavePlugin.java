package com.lemarcbzh.cotation;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import java.io.OutputStream;

@CapacitorPlugin(name = "CotationSave")
public class CotationSavePlugin extends Plugin {

    @PluginMethod
    public void save(PluginCall call) {
        String name = call.getString("name");
        String mime = call.getString("mime", "application/octet-stream");
        String data = call.getString("data");
        boolean image = "image".equals(call.getString("kind"));
        if (name == null || data == null) {
            call.reject("Parametres manquants");
            return;
        }
        if (Build.VERSION.SDK_INT < 29) {
            call.reject("Android 10 minimum requis");
            return;
        }
        try {
            byte[] bytes = Base64.decode(data, Base64.DEFAULT);
            ContentResolver r = getContext().getContentResolver();
            ContentValues v = new ContentValues();
            v.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
            v.put(MediaStore.MediaColumns.MIME_TYPE, mime);
            String base = image ? Environment.DIRECTORY_PICTURES : Environment.DIRECTORY_DOCUMENTS;
            v.put(MediaStore.MediaColumns.RELATIVE_PATH, base + "/Cotation");
            v.put(MediaStore.MediaColumns.IS_PENDING, 1);
            Uri col = image
                ? MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
                : MediaStore.Files.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY);
            Uri uri = r.insert(col, v);
            if (uri == null) {
                call.reject("Creation du fichier impossible");
                return;
            }
            OutputStream os = r.openOutputStream(uri);
            os.write(bytes);
            os.close();
            ContentValues done = new ContentValues();
            done.put(MediaStore.MediaColumns.IS_PENDING, 0);
            r.update(uri, done, null, null);
            JSObject ret = new JSObject();
            ret.put("uri", uri.toString());
            call.resolve(ret);
        } catch (Exception e) {
            call.reject("Erreur : " + e.getMessage());
        }
    }
}
