package com.lemarcbzh.cotation;

import android.os.Bundle;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        registerPlugin(CotationSavePlugin.class);
        super.onCreate(savedInstanceState);
    }
}
