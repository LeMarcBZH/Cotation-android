import os, re

# 1) Numero de version qui augmente a chaque construction + signature fixe
g = 'android/app/build.gradle'
if os.path.exists(g):
    s = open(g).read()
    n = os.environ.get('GITHUB_RUN_NUMBER', '1')
    s = re.sub(r'versionCode\s+\d+', 'versionCode ' + n, s)
    s = re.sub(r'versionName\s+"[^"]*"', 'versionName "1.' + n + '"', s)
    block = '''android {
    signingConfigs {
        debug {
            storeFile file("${rootProject.projectDir}/../debug.keystore")
            storePassword "android"
            keyAlias "androiddebugkey"
            keyPassword "android"
        }
    }
'''
    if 'signingConfigs' not in s:
        s = re.sub(r'^android \{\s*\n', block, s, count=1, flags=re.M)
    # identifiant different : s'installe a cote de l'ancienne version, sans conflit de signature
    s = re.sub(r'applicationId\s+"[^"]*"', 'applicationId "com.lemarcbzh.cotation2"', s)
    open(g, 'w').write(s)
    st = 'android/app/src/main/res/values/strings.xml'
    if os.path.exists(st):
        t = open(st).read()
        t = re.sub(r'(<string name="app_name">)[^<]*', r'\1Cotation 2', t)
        t = re.sub(r'(<string name="title_activity_main">)[^<]*', r'\1Cotation 2', t)
        open(st, 'w').write(t)

# 2) Icone (optionnel)
try:
    from PIL import Image
    src = Image.open('assets/icon-fg.png').convert('RGBA')
    for d, sz in {'mdpi':108,'hdpi':162,'xhdpi':216,'xxhdpi':324,'xxxhdpi':432}.items():
        p = f'android/app/src/main/res/mipmap-{d}/ic_launcher_foreground.png'
        if os.path.exists(p):
            src.resize((sz, sz), Image.LANCZOS).save(p)
    open('android/app/src/main/res/values/ic_launcher_background.xml', 'w').write(
        '<?xml version="1.0" encoding="utf-8"?><resources><color name="ic_launcher_background">#1E1E1E</color></resources>')
except Exception as e:
    print('icone ignoree :', e)
