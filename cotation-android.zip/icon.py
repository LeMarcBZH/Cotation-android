from PIL import Image
import os
src = Image.open('assets/icon-fg.png').convert('RGBA')
for d, s in {'mdpi':108,'hdpi':162,'xhdpi':216,'xxhdpi':324,'xxxhdpi':432}.items():
    p = f'android/app/src/main/res/mipmap-{d}/ic_launcher_foreground.png'
    if os.path.exists(p):
        src.resize((s, s), Image.LANCZOS).save(p)
open('android/app/src/main/res/values/ic_launcher_background.xml','w').write(
 '<?xml version="1.0" encoding="utf-8"?><resources><color name="ic_launcher_background">#1E1E1E</color></resources>')
